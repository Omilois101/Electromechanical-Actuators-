construct_actuator : File conating the Plot, Femm process and Analytical equations 
BHMODEL: simscape magnetic equivalent circuit model
B-Hcurve: Extracts of the B-H curve from FEMM. 